<?php
/**
 * =========================================================================
 * Стоматология «Добрый Доктор» (г. Сургут) — Универсальный API бэкенд (PHP)
 * Для работы на классическом виртуальном хостинге (Beget, Timeweb, Reg.ru и др.)
 * =========================================================================
 */

// Заголовки CORS и кодировки
header('Content-Type: application/json; charset=utf-8');
header('Access-Control-Allow-Origin: *');
header('Access-Control-Allow-Methods: GET, POST, PUT, DELETE, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, Authorization');

// Preflight OPTIONS
if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') {
    http_response_code(204);
    exit;
}

$dbPath = __DIR__ . '/data/database.json';

// Функция чтения базы данных
function getDatabase($path) {
    if (!file_exists($path)) {
        return [
            'clinic' => [],
            'hero' => [],
            'services' => [],
            'doctors' => [],
            'gallery' => [],
            'leads' => []
        ];
    }
    $content = file_get_contents($path);
    $data = json_decode($content, true);
    return is_array($data) ? $data : [];
}

// Функция безопасной записи базы данных с блокировкой файла
function saveDatabase($path, $data) {
    $dir = dirname($path);
    if (!is_dir($dir)) {
        mkdir($dir, 0755, true);
    }
    $json = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    return file_put_contents($path, $json, LOCK_EX) !== false;
}

// Получение тела запроса JSON
function getRequestBody() {
    $raw = file_get_contents('php://input');
    if (empty($raw)) return [];
    $data = json_decode($raw, true);
    return is_array($data) ? $data : [];
}

// Определение маршрута
$method = $_SERVER['REQUEST_METHOD'];
$route = isset($_GET['route']) ? trim($_GET['route'], '/') : '';

// Если передан чистый URI
if (empty($route)) {
    $uri = parse_url($_SERVER['REQUEST_URI'], PHP_URL_PATH);
    $route = preg_replace('#^/api/?#', '', $uri);
    $route = trim($route, '/');
}

$parts = explode('/', $route);
$resource = $parts[0] ?? '';
$id = $parts[1] ?? null;

$db = getDatabase($dbPath);

// =========================================================================
// МАРШРУТИЗАЦИЯ
// =========================================================================

// 1. Полные данные сайта
if ($resource === 'data' && $method === 'GET') {
    echo json_encode($db, JSON_UNESCAPED_UNICODE);
    exit;
}

// 2. Авторизация администратора
if ($resource === 'auth' && ($id === 'login' || empty($id)) && $method === 'POST') {
    $body = getRequestBody();
    $username = $body['username'] ?? '';
    $password = $body['password'] ?? '';
    if ($username === 'admin' && $password === 'admin') {
        echo json_encode([
            'success' => true,
            'token' => 'dd_token_' . time(),
            'user' => ['name' => 'Главный Администратор', 'role' => 'admin']
        ], JSON_UNESCAPED_UNICODE);
    } else {
        http_response_code(401);
        echo json_encode(['error' => 'Неверный логин или пароль'], JSON_UNESCAPED_UNICODE);
    }
    exit;
}

// 3. Заявки (Лиды)
if ($resource === 'leads') {
    if ($method === 'GET') {
        echo json_encode($db['leads'] ?? [], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'POST') {
        $body = getRequestBody();
        $name = trim($body['name'] ?? '');
        $phone = trim($body['phone'] ?? '');
        if (empty($name) || empty($phone)) {
            http_response_code(400);
            echo json_encode(['error' => 'Имя и телефон обязательны'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        $newLead = [
            'id' => time() . rand(100, 999),
            'name' => $name,
            'phone' => $phone,
            'service' => $body['service'] ?? 'Не выбрана',
            'comment' => $body['comment'] ?? '',
            'source' => $body['source'] ?? 'Форма записи',
            'status' => 'new',
            'createdAt' => date('c')
        ];
        if (!isset($db['leads'])) $db['leads'] = [];
        array_unshift($db['leads'], $newLead);
        saveDatabase($dbPath, $db);

        // Отправка уведомления на email клиники при наличии настройки
        $adminEmail = $db['clinic']['email'] ?? 'stomatologiya-surgut@yandex.ru';
        $subject = "Новая запись на прием — «Добрый Доктор» ({$name})";
        $msg = "Получена новая заявка с сайта:\n\nИмя: {$name}\nТелефон: {$phone}\nУслуга: {$newLead['service']}\nКомментарий: {$newLead['comment']}\nВремя: " . date('d.m.Y H:i');
        @mail($adminEmail, '=?UTF-8?B?'.base64_encode($subject).'?=', $msg, "Content-Type: text/plain; charset=utf-8\r\nFrom: no-reply@" . ($_SERVER['HTTP_HOST'] ?? 'surgut-clinic.ru'));

        echo json_encode(['success' => true, 'lead' => $newLead], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'PUT' && $id) {
        $body = getRequestBody();
        $newStatus = $body['status'] ?? 'new';
        $found = false;
        foreach ($db['leads'] as &$lead) {
            if ((string)$lead['id'] === (string)$id) {
                $lead['status'] = $newStatus;
                $found = true;
                break;
            }
        }
        if ($found) {
            saveDatabase($dbPath, $db);
            echo json_encode(['success' => true, 'message' => 'Статус обновлен'], JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Заявка не найдена'], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
    if ($method === 'DELETE' && $id) {
        $initial = count($db['leads']);
        $db['leads'] = array_values(array_filter($db['leads'], function($lead) use ($id) {
            return (string)$lead['id'] !== (string)$id;
        }));
        if (count($db['leads']) < $initial) {
            saveDatabase($dbPath, $db);
            echo json_encode(['success' => true, 'message' => 'Заявка удалена'], JSON_UNESCAPED_UNICODE);
        } else {
            http_response_code(404);
            echo json_encode(['error' => 'Заявка не найдена'], JSON_UNESCAPED_UNICODE);
        }
        exit;
    }
}

// 4. Тексты и Конфигурация клиники
if ($resource === 'config') {
    if ($method === 'GET') {
        echo json_encode(['clinic' => $db['clinic'] ?? [], 'hero' => $db['hero'] ?? []], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'POST') {
        $body = getRequestBody();
        if (isset($body['clinic'])) {
            $db['clinic'] = array_merge($db['clinic'] ?? [], $body['clinic']);
        }
        if (isset($body['hero'])) {
            $db['hero'] = array_merge($db['hero'] ?? [], $body['hero']);
        }
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'message' => 'Настройки обновлены'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// 5. Услуги
if ($resource === 'services') {
    if ($method === 'GET') {
        echo json_encode($db['services'] ?? [], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'POST') {
        $body = getRequestBody();
        if (empty($body['name'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Название услуги обязательно'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if (isset($body['id']) && $body['id'] !== '') {
            foreach ($db['services'] as &$s) {
                if ((string)$s['id'] === (string)$body['id']) {
                    $s = array_merge($s, $body);
                    break;
                }
            }
        } else {
            $body['id'] = time() . rand(10, 99);
            $db['services'][] = $body;
        }
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'service' => $body], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'DELETE' && $id) {
        $db['services'] = array_values(array_filter($db['services'], function($s) use ($id) {
            return (string)$s['id'] !== (string)$id;
        }));
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'message' => 'Услуга удалена'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// 6. Врачи (Специалисты)
if ($resource === 'doctors') {
    if ($method === 'GET') {
        echo json_encode($db['doctors'] ?? [], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'POST') {
        $body = getRequestBody();
        if (empty($body['name'])) {
            http_response_code(400);
            echo json_encode(['error' => 'ФИО специалиста обязательно'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if (isset($body['id']) && $body['id'] !== '') {
            foreach ($db['doctors'] as &$d) {
                if ((string)$d['id'] === (string)$body['id']) {
                    $d = array_merge($d, $body);
                    break;
                }
            }
        } else {
            $body['id'] = time() . rand(10, 99);
            $db['doctors'][] = $body;
        }
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'doctor' => $body], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'DELETE' && $id) {
        $db['doctors'] = array_values(array_filter($db['doctors'], function($d) use ($id) {
            return (string)$d['id'] !== (string)$id;
        }));
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'message' => 'Специалист удален'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// 7. Галерея
if ($resource === 'gallery') {
    if ($method === 'GET') {
        echo json_encode($db['gallery'] ?? [], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'POST') {
        $body = getRequestBody();
        if (empty($body['url'])) {
            http_response_code(400);
            echo json_encode(['error' => 'Ссылка на изображение обязательна'], JSON_UNESCAPED_UNICODE);
            exit;
        }
        if (isset($body['id']) && $body['id'] !== '') {
            foreach ($db['gallery'] as &$g) {
                if ((string)$g['id'] === (string)$body['id']) {
                    $g = array_merge($g, $body);
                    break;
                }
            }
        } else {
            $body['id'] = time() . rand(10, 99);
            $db['gallery'][] = $body;
        }
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'item' => $body], JSON_UNESCAPED_UNICODE);
        exit;
    }
    if ($method === 'DELETE' && $id) {
        $db['gallery'] = array_values(array_filter($db['gallery'], function($g) use ($id) {
            return (string)$g['id'] !== (string)$id;
        }));
        saveDatabase($dbPath, $db);
        echo json_encode(['success' => true, 'message' => 'Изображение удалено'], JSON_UNESCAPED_UNICODE);
        exit;
    }
}

// Неизвестный маршрут
http_response_code(404);
echo json_encode(['error' => 'Маршрут не найден: ' . $resource], JSON_UNESCAPED_UNICODE);
