/**
 * =========================================================================
 *  Стоматология «Добрый Доктор» — Backend Server & REST API
 *  Zero-dependency Node.js HTTP Server with dynamic JSON Database & File Uploads
 * =========================================================================
 */

const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const PORT = process.env.PORT || 3000;
const DB_PATH = path.join(__dirname, 'data', 'database.json');
const UPLOADS_DIR = path.join(__dirname, 'uploads');

// Ensure directories exist
if (!fs.existsSync(path.join(__dirname, 'data'))) {
    fs.mkdirSync(path.join(__dirname, 'data'), { recursive: true });
}
if (!fs.existsSync(UPLOADS_DIR)) {
    fs.mkdirSync(UPLOADS_DIR, { recursive: true });
}

// Helper: read database
function readDB() {
    try {
        if (!fs.existsSync(DB_PATH)) {
            return { clinic: {}, hero: {}, services: [], doctors: [], gallery: [], leads: [] };
        }
        const raw = fs.readFileSync(DB_PATH, 'utf8');
        const db = JSON.parse(raw);
        db.doctors = db.doctors || [];
        return db;
    } catch (e) {
        console.error('Error reading database:', e);
        return { clinic: {}, hero: {}, services: [], doctors: [], gallery: [], leads: [] };
    }
}

// Helper: write database
function writeDB(data) {
    try {
        fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf8');
        return true;
    } catch (e) {
        console.error('Error writing database:', e);
        return false;
    }
}

// MIME Types
const MIME_TYPES = {
    '.html': 'text/html; charset=utf-8',
    '.css': 'text/css; charset=utf-8',
    '.js': 'application/javascript; charset=utf-8',
    '.json': 'application/json; charset=utf-8',
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.webp': 'image/webp',
    '.svg': 'image/svg+xml',
    '.ico': 'image/x-icon',
    '.woff': 'font/woff',
    '.woff2': 'font/woff2',
    '.ttf': 'font/ttf'
};

// Parse JSON request body with support for large Base64 images (up to 20MB)
function parseBody(req) {
    return new Promise((resolve, reject) => {
        let body = '';
        req.on('data', chunk => {
            body += chunk.toString();
            // 20MB safety limit
            if (body.length > 20 * 1024 * 1024) {
                req.destroy();
                reject(new Error('Payload Too Large'));
            }
        });
        req.on('end', () => {
            if (!body) return resolve({});
            try {
                resolve(JSON.parse(body));
            } catch (err) {
                resolve({ raw: body });
            }
        });
        req.on('error', reject);
    });
}

// Send JSON response
function sendJSON(res, statusCode, data) {
    res.writeHead(statusCode, {
        'Content-Type': 'application/json; charset=utf-8',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
        'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end(JSON.stringify(data));
}

// HTTP Server
const server = http.createServer(async (req, res) => {
    const parsedUrl = url.parse(req.url, true);
    const pathname = parsedUrl.pathname;
    const method = req.method;

    // CORS preflight
    if (method === 'OPTIONS') {
        res.writeHead(204, {
            'Access-Control-Allow-Origin': '*',
            'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
            'Access-Control-Allow-Headers': 'Content-Type, Authorization'
        });
        return res.end();
    }

    // =========================================================================
    // REST API ROUTES
    // =========================================================================

    // 1. GET /api/data -> Get all data (clinic, hero, services, doctors, gallery, leads)
    if (pathname === '/api/data' && method === 'GET') {
        const db = readDB();
        return sendJSON(res, 200, db);
    }

    // 1b. Granular GET endpoints
    if (pathname === '/api/leads' && method === 'GET') {
        const db = readDB();
        return sendJSON(res, 200, db.leads || []);
    }
    if (pathname === '/api/services' && method === 'GET') {
        const db = readDB();
        return sendJSON(res, 200, db.services || []);
    }
    if (pathname === '/api/doctors' && method === 'GET') {
        const db = readDB();
        return sendJSON(res, 200, db.doctors || []);
    }
    if (pathname === '/api/gallery' && method === 'GET') {
        const db = readDB();
        return sendJSON(res, 200, db.gallery || []);
    }
    if (pathname === '/api/config' && method === 'GET') {
        const db = readDB();
        return sendJSON(res, 200, { clinic: db.clinic, hero: db.hero });
    }

    // 2. POST /api/leads -> Create a new lead from appointment form
    if (pathname === '/api/leads' && method === 'POST') {
        try {
            const body = await parseBody(req);
            if (!body.name || !body.phone) {
                return sendJSON(res, 400, { error: 'Пожалуйста, укажите имя и телефон' });
            }

            const db = readDB();
            const newLead = {
                id: Date.now(),
                name: String(body.name).trim(),
                phone: String(body.phone).trim(),
                service: body.service ? String(body.service).trim() : 'Общая консультация',
                comment: body.comment ? String(body.comment).trim() : '',
                date: new Date().toISOString(),
                status: 'new'
            };

            db.leads = db.leads || [];
            db.leads.unshift(newLead);
            writeDB(db);

            return sendJSON(res, 201, { success: true, lead: newLead, message: 'Заявка успешно принята!' });
        } catch (e) {
            return sendJSON(res, 500, { error: 'Ошибка сохранения заявки' });
        }
    }

    // 3. PUT /api/leads/:id -> Update lead status
    if (pathname.startsWith('/api/leads/') && method === 'PUT') {
        const idStr = pathname.replace('/api/leads/', '');
        const id = parseInt(idStr, 10);
        const body = await parseBody(req);
        const db = readDB();

        const lead = (db.leads || []).find(l => l.id === id || String(l.id) === idStr);
        if (!lead) {
            return sendJSON(res, 404, { error: 'Заявка не найдена' });
        }

        if (body.status) lead.status = body.status;
        writeDB(db);
        return sendJSON(res, 200, { success: true, lead });
    }

    // 4. DELETE /api/leads/:id -> Delete lead
    if (pathname.startsWith('/api/leads/') && method === 'DELETE') {
        const idStr = pathname.replace('/api/leads/', '');
        const id = parseInt(idStr, 10);
        const db = readDB();
        db.leads = (db.leads || []).filter(l => l.id !== id && String(l.id) !== idStr);
        writeDB(db);
        return sendJSON(res, 200, { success: true, message: 'Заявка удалена' });
    }

    // 5. POST /api/config -> Update general clinic & hero texts/settings
    if (pathname === '/api/config' && method === 'POST') {
        const body = await parseBody(req);
        const db = readDB();

        if (body.clinic) db.clinic = { ...db.clinic, ...body.clinic };
        if (body.hero) db.hero = { ...db.hero, ...body.hero };
        writeDB(db);

        return sendJSON(res, 200, { success: true, message: 'Настройки и тексты успешно обновлены!' });
    }

    // 6. POST /api/services -> Add or Update service
    if (pathname === '/api/services' && method === 'POST') {
        const body = await parseBody(req);
        const db = readDB();
        db.services = db.services || [];

        if (body.id) {
            const index = db.services.findIndex(s => s.id === parseInt(body.id, 10));
            if (index !== -1) {
                db.services[index] = { ...db.services[index], ...body, id: parseInt(body.id, 10) };
            }
        } else {
            const newService = {
                id: Date.now(),
                title: body.title || 'Новая услуга',
                category: body.category || 'therapy',
                icon: body.icon || 'fa-tooth',
                description: body.description || '',
                priceFrom: parseInt(body.priceFrom, 10) || 0,
                badge: body.badge || '',
                active: body.active !== undefined ? body.active : true
            };
            db.services.push(newService);
        }

        writeDB(db);
        return sendJSON(res, 200, { success: true, services: db.services });
    }

    // 7. DELETE /api/services/:id -> Delete service
    if (pathname.startsWith('/api/services/') && method === 'DELETE') {
        const idStr = pathname.replace('/api/services/', '');
        const id = parseInt(idStr, 10);
        const db = readDB();
        db.services = (db.services || []).filter(s => s.id !== id && String(s.id) !== idStr);
        writeDB(db);
        return sendJSON(res, 200, { success: true, message: 'Услуга удалена' });
    }

    // 8. POST /api/doctors -> Add or Update doctor with cropped photo
    if (pathname === '/api/doctors' && method === 'POST') {
        const body = await parseBody(req);
        const db = readDB();
        db.doctors = db.doctors || [];

        if (body.id) {
            const index = db.doctors.findIndex(d => d.id === parseInt(body.id, 10) || String(d.id) === String(body.id));
            if (index !== -1) {
                db.doctors[index] = { ...db.doctors[index], ...body, id: parseInt(body.id, 10) || body.id };
            }
        } else {
            const newDoctor = {
                id: Date.now(),
                name: body.name || 'Новый специалист',
                specialization: body.specialization || 'Стоматолог',
                experience: parseInt(body.experience, 10) || 5,
                photo: body.photo || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80',
                badge: body.badge || '',
                description: body.description || '',
                active: body.active !== undefined ? body.active : true
            };
            db.doctors.push(newDoctor);
        }

        writeDB(db);
        return sendJSON(res, 200, { success: true, doctors: db.doctors });
    }

    // 9. DELETE /api/doctors/:id -> Delete doctor
    if (pathname.startsWith('/api/doctors/') && method === 'DELETE') {
        const idStr = pathname.replace('/api/doctors/', '');
        const id = parseInt(idStr, 10);
        const db = readDB();
        db.doctors = (db.doctors || []).filter(d => d.id !== id && String(d.id) !== idStr);
        writeDB(db);
        return sendJSON(res, 200, { success: true, message: 'Специалист удален' });
    }

    // 10. POST /api/gallery -> Add or update media image
    if (pathname === '/api/gallery' && method === 'POST') {
        const body = await parseBody(req);
        const db = readDB();
        db.gallery = db.gallery || [];

        if (body.id) {
            const index = db.gallery.findIndex(g => g.id === parseInt(body.id, 10) || String(g.id) === String(body.id));
            if (index !== -1) {
                db.gallery[index] = { ...db.gallery[index], ...body };
            }
        } else {
            const newImage = {
                id: Date.now(),
                title: body.title || 'Фото клиники',
                category: body.category || 'Интерьер',
                url: body.url || ''
            };
            db.gallery.push(newImage);
        }

        writeDB(db);
        return sendJSON(res, 200, { success: true, gallery: db.gallery });
    }

    // 11. DELETE /api/gallery/:id -> Delete gallery item
    if (pathname.startsWith('/api/gallery/') && method === 'DELETE') {
        const idStr = pathname.replace('/api/gallery/', '');
        const id = parseInt(idStr, 10);
        const db = readDB();
        db.gallery = (db.gallery || []).filter(g => g.id !== id && String(g.id) !== idStr);
        writeDB(db);
        return sendJSON(res, 200, { success: true, message: 'Изображение удалено' });
    }

    // 12. POST /api/auth/login -> Authenticate admin
    if (pathname === '/api/auth/login' && method === 'POST') {
        const body = await parseBody(req);
        if (body.username === 'admin' && body.password === 'admin') {
            return sendJSON(res, 200, {
                success: true,
                token: 'dd_token_' + Date.now(),
                user: { name: 'Главный Администратор', role: 'admin' }
            });
        }
        return sendJSON(res, 401, { error: 'Неверный логин или пароль' });
    }

    // =========================================================================
    // STATIC FILE SERVING
    // =========================================================================
    let safePath = path.normalize(pathname).replace(/^(\.\.[\/\\])+/, '');
    if (safePath === '/' || safePath === '\\') {
        safePath = '/index.html';
    } else if (safePath === '/admin' || safePath === '/admin/') {
        safePath = '/admin/dashboard.html';
    }

    const filePath = path.join(__dirname, safePath);
    const extname = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[extname] || 'application/octet-stream';

    fs.readFile(filePath, (err, content) => {
        if (err) {
            if (err.code === 'ENOENT') {
                res.writeHead(404, { 'Content-Type': 'text/html; charset=utf-8' });
                res.end('<h1>404 Не найдено</h1><p>Запрашиваемая страница не существует.</p><a href="/">На главную</a>');
            } else {
                res.writeHead(500);
                res.end(`Server Error: ${err.code}`);
            }
        } else {
            res.writeHead(200, { 'Content-Type': contentType });
            res.end(content);
        }
    });
});

server.listen(PORT, () => {
    console.log(`\n======================================================`);
    console.log(` 🦷 Стоматология «Добрый Доктор» (г. Сургут)`);
    console.log(` 🚀 Сервер запущен: http://localhost:${PORT}`);
    console.log(` 🌐 Главный сайт:     http://localhost:${PORT}/`);
    console.log(` 🔐 Панель CMS:       http://localhost:${PORT}/admin/dashboard.html`);
    console.log(`======================================================\n`);
});
