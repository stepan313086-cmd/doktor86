/**
 * =========================================================================
 *  Стоматология «Добрый Доктор» (г. Сургут) — Клиентский JavaScript
 *  100% Dynamic CMS Rendering + Yandex Maps API + Mobile Drawer Handlers
 * =========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {
    // State
    let siteData = null;
    let activeCategory = 'all';

    // =========================================================================
    // 1. DATA LOADER & CMS SYNC
    // =========================================================================
    async function loadSiteData() {
        try {
            // First attempt to fetch from backend REST API
            const response = await fetch('/api/data', { cache: 'no-store' });
            if (response.ok) {
                siteData = await response.json();
                localStorage.setItem('dd_cached_db', JSON.stringify(siteData));
                renderAllContent(siteData);
                initYandexMap(siteData.clinic);
                return;
            }
        } catch (e) {
            console.warn('API /api/data unavailable, attempting static JSON fallback...');
        }

        // Static fallback to data/database.json or localStorage cache
        try {
            const cached = localStorage.getItem('dd_cached_db');
            if (cached) {
                siteData = JSON.parse(cached);
                renderAllContent(siteData);
                initYandexMap(siteData.clinic);
            }

            const staticResp = await fetch('data/database.json');
            if (staticResp.ok) {
                siteData = await staticResp.json();
                renderAllContent(siteData);
                initYandexMap(siteData.clinic);
            }
        } catch (err) {
            console.error('Failed to load database config:', err);
        }
    }

    // =========================================================================
    // 2. DYNAMIC CONTENT RENDERER
    // =========================================================================
    function renderAllContent(data) {
        if (!data) return;

        const clinic = data.clinic || {};
        const hero = data.hero || {};
        const services = data.services || [];
        const doctors = data.doctors || [];
        const gallery = data.gallery || [];

        // Header & Topbar (Strictly 1 Line)
        setText('headerAddress', `${clinic.address || 'г. Сургут, ул. 30 лет Победы, 44/А'}, ${clinic.addressDetails || 'этаж 2, оф. 208'}`);
        setText('headerRatingVal', clinic.rating || '4.4');
        setText('headerHours', `Пн–Пт: ${clinic.workingHours?.weekdays || '09:00–20:00'}, Сб: ${clinic.workingHours?.saturday || '10:00–18:00'}`);
        setText('headerPhoneText', clinic.phone || '+7 (922) 447-98-88');
        setHref('headerPhoneLink', `tel:${clinic.phoneRaw || '+79224479888'}`);
        setHref('headerWaLink', clinic.whatsapp || 'https://wa.me/79224479888');
        setHref('headerTgLink', clinic.telegram || 'https://t.me/dobrydoctor_surgut');
        setHref('headerVkLink', clinic.vk || 'https://vk.com/dobrydoctor_surgut');

        // Hero Section
        setText('heroRatingText', `Рейтинг ${clinic.rating || '4.4'} ⭐ на ${clinic.ratingPlatform || 'Яндекс Картах'} • ${clinic.city || 'Сургут'}`);
        setText('heroTitle', hero.title || 'Стоматология «Добрый Доктор» — бережное лечение зубов в Сургуте');
        setText('heroSubtitle', hero.subtitle || 'Рейтинг 4.4 ⭐. Профессиональная команда, современное оборудование и комфортная атмосфера.');
        setHref('heroWaBtn', `${clinic.whatsapp || 'https://wa.me/79224479888'}?text=Здравствуйте!%20Хочу%20записаться%20на%20приём%20в%20клинику%20«Добрый%20Доктор»`);

        // Contacts Section
        setText('contactAddressFull', clinic.address || 'г. Сургут, ул. 30 лет Победы, 44/А');
        setText('contactAddressOffice', clinic.addressDetails || 'Этаж 2, Офис 208');
        setText('contactPhoneLink', clinic.phone || '+7 (922) 447-98-88');
        setHref('contactPhoneLink', `tel:${clinic.phoneRaw || '+79224479888'}`);
        setHref('contactWaBtn', clinic.whatsapp || 'https://wa.me/79224479888');
        setHref('contactTgBtn', clinic.telegram || 'https://t.me/dobrydoctor_surgut');
        setHref('contactVkBtn', clinic.vk || 'https://vk.com/dobrydoctor_surgut');

        if (clinic.workingHours) {
            setText('contactScheduleWeekdays', `Понедельник — Пятница: ${clinic.workingHours.weekdays}`);
            setText('contactScheduleSat', `Суббота: ${clinic.workingHours.saturday}`);
            setText('contactScheduleSun', `Воскресенье: ${clinic.workingHours.sunday}`);
        }

        // Render Services
        renderServices(services);

        // Render Doctors
        renderDoctors(doctors);

        // Render Gallery
        renderGallery(gallery);
    }

    // Helper functions
    function setText(id, text) {
        const el = document.getElementById(id);
        if (el && text) el.textContent = text;
    }

    function setHref(id, href) {
        const el = document.getElementById(id);
        if (el && href) el.href = href;
    }

    // =========================================================================
    // 3. RENDER SERVICES (GRID & FILTERING)
    // =========================================================================
    function renderServices(servicesList) {
        const grid = document.getElementById('servicesGrid');
        if (!grid) return;

        const filtered = activeCategory === 'all' 
            ? servicesList.filter(s => s.active !== false)
            : servicesList.filter(s => s.active !== false && s.category === activeCategory);

        if (filtered.length === 0) {
            grid.innerHTML = `<div style="grid-column: 1/-1; text-align: center; padding: 40px; color: var(--text-muted);">
                Услуги в данной категории не найдены.
            </div>`;
            return;
        }

        grid.innerHTML = filtered.map(service => `
            <div class="service-card" data-category="${service.category}">
                ${service.badge ? `<span class="service-card__badge">${escapeHtml(service.badge)}</span>` : ''}
                <div class="service-card__icon-box">
                    <i class="fas ${service.icon || 'fa-tooth'}"></i>
                </div>
                <h3 class="service-card__title">${escapeHtml(service.title)}</h3>
                <p class="service-card__desc">${escapeHtml(service.description)}</p>
                <div class="service-card__footer">
                    <div class="service-card__price">
                        <span class="service-card__price-label">Стоимость:</span>
                        <span class="service-card__price-val">от ${Number(service.priceFrom || 0).toLocaleString('ru-RU')} ₽</span>
                    </div>
                    <button class="btn btn--primary service-card__btn" data-service-select="${escapeHtml(service.title)}">
                        Записаться
                    </button>
                </div>
            </div>
        `).join('');

        // Attach modal trigger to service buttons
        grid.querySelectorAll('[data-service-select]').forEach(btn => {
            btn.addEventListener('click', () => {
                const serviceName = btn.getAttribute('data-service-select');
                openAppointmentModal(serviceName);
            });
        });
    }

    // Filter Buttons logic
    const filterBtns = document.querySelectorAll('#serviceFilters .filter-btn');
    filterBtns.forEach(btn => {
        btn.addEventListener('click', () => {
            filterBtns.forEach(b => b.classList.remove('active'));
            btn.classList.add('active');
            activeCategory = btn.dataset.filter || 'all';
            if (siteData && siteData.services) {
                renderServices(siteData.services);
            }
        });
    });

    // =========================================================================
    // 4. RENDER DOCTORS (НАШИ СПЕЦИАЛИСТЫ)
    // =========================================================================
    function renderDoctors(doctorsList) {
        const grid = document.getElementById('doctorsGrid');
        if (!grid || !doctorsList || doctorsList.length === 0) return;

        const activeDoctors = doctorsList.filter(d => d.active !== false);

        grid.innerHTML = activeDoctors.map(doc => `
            <div class="doctor-card">
                <div class="doctor-card__photo-box">
                    <img src="${escapeHtml(doc.photo || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80')}" alt="${escapeHtml(doc.name)}" loading="lazy">
                    ${doc.badge ? `<span class="doctor-card__badge">${escapeHtml(doc.badge)}</span>` : ''}
                </div>
                <div class="doctor-card__body">
                    <h3 class="doctor-card__name">${escapeHtml(doc.name)}</h3>
                    <div class="doctor-card__spec">${escapeHtml(doc.specialization)}</div>
                    <div class="doctor-card__exp">
                        <i class="fas fa-user-clock"></i>
                        <span>Стаж работы: <strong>${doc.experience || 10} лет</strong></span>
                    </div>
                    <p class="doctor-card__desc">${escapeHtml(doc.description || '')}</p>
                    <button class="btn btn--outline doctor-card__btn" data-doctor-book="${escapeHtml(doc.name)}">
                        <i class="fas fa-calendar-check"></i> Записаться к врачу
                    </button>
                </div>
            </div>
        `).join('');

        // Attach booking click
        grid.querySelectorAll('[data-doctor-book]').forEach(btn => {
            btn.addEventListener('click', () => {
                const docName = btn.getAttribute('data-doctor-book');
                openAppointmentModal(`Запись к врачу: ${docName}`);
            });
        });
    }

    // =========================================================================
    // 5. RENDER GALLERY
    // =========================================================================
    function renderGallery(galleryList) {
        const grid = document.getElementById('galleryGrid');
        if (!grid || !galleryList || galleryList.length === 0) return;

        grid.innerHTML = galleryList.map(item => `
            <div class="gallery-card">
                <div class="gallery-card__img">
                    <img src="${escapeHtml(item.url)}" alt="${escapeHtml(item.title)}" loading="lazy">
                </div>
                <div class="gallery-card__body">
                    <span class="gallery-card__cat">${escapeHtml(item.category || 'Клиника')}</span>
                    <h4 class="gallery-card__title">${escapeHtml(item.title)}</h4>
                </div>
            </div>
        `).join('');
    }

    // =========================================================================
    // 6. INTERACTIVE YANDEX MAP API (100% ТОЧНЫЙ АДРЕС В СУРГУТЕ)
    // =========================================================================
    let yandexMapInstance = null;

    function initYandexMap(clinicInfo = {}) {
        if (typeof ymaps === 'undefined') return;

        ymaps.ready(() => {
            const mapContainer = document.getElementById('yandexMapContainer');
            if (!mapContainer || yandexMapInstance) return;

            const exactCoords = clinicInfo.mapCoords || [61.253580, 73.431534];

            // Remove static iframe if JS API is available
            const iframe = document.getElementById('yandexMapIframe');
            if (iframe) iframe.remove();

            try {
                yandexMapInstance = new ymaps.Map('yandexMapContainer', {
                    center: exactCoords,
                    zoom: 17,
                    controls: ['zoomControl', 'fullscreenControl', 'geolocationControl']
                }, {
                    searchControlProvider: 'yandex#search'
                });

                // Prevent unintentional scroll on mobile
                yandexMapInstance.behaviors.disable('scrollZoom');

                // Custom Placemark on exact building
                const clinicPlacemark = new ymaps.Placemark(exactCoords, {
                    hintContent: 'Стоматология «Добрый Доктор»',
                    balloonContentHeader: '<strong style="color:#2E86C1;font-size:16px;">Стоматология «Добрый Доктор»</strong>',
                    balloonContentBody: `
                        <div style="font-size:13px;line-height:1.6;padding:4px 0;">
                            <p>📍 <strong>г. Сургут, ул. 30 лет Победы, 44/А</strong></p>
                            <p>🏢 БЦ «Север», 2 этаж, офис 208</p>
                            <p>📞 <a href="tel:+79224479888" style="color:#2E86C1;font-weight:700;">+7 (922) 447-98-88</a></p>
                            <p>⏰ Пн–Пт: 09:00–20:00, Сб: 10:00–18:00</p>
                        </div>
                    `,
                    balloonContentFooter: '<a href="https://yandex.ru/maps/?pt=73.431534,61.253580&z=17&l=map" target="_blank" style="color:#1ABC9C;font-size:12px;font-weight:600;text-decoration:underline;">Маршрут на Яндекс Картах (4.4 ⭐)</a>'
                }, {
                    preset: 'islands#blueMedicalIcon',
                    iconColor: '#2E86C1'
                });

                yandexMapInstance.geoObjects.add(clinicPlacemark);
            } catch (err) {
                console.warn('Map initialization notice:', err);
            }
        });
    }

    // =========================================================================
    // 7. PHONE INPUT MASK (+7 format)
    // =========================================================================
    function setupPhoneMask(input) {
        if (!input) return;
        input.addEventListener('input', (e) => {
            let value = e.target.value.replace(/\D/g, '');
            if (value.length > 0) {
                if (value[0] === '8') value = '7' + value.slice(1);
                if (value[0] !== '7') value = '7' + value;
            }

            let formatted = '';
            if (value.length > 0) formatted = '+7';
            if (value.length > 1) formatted += ' (' + value.slice(1, 4);
            if (value.length > 4) formatted += ') ' + value.slice(4, 7);
            if (value.length > 7) formatted += '-' + value.slice(7, 9);
            if (value.length > 9) formatted += '-' + value.slice(9, 11);

            e.target.value = formatted;
        });

        input.addEventListener('focus', (e) => {
            if (!e.target.value) e.target.value = '+7';
        });

        input.addEventListener('blur', (e) => {
            if (e.target.value === '+7') e.target.value = '';
        });
    }

    document.querySelectorAll('input[type="tel"]').forEach(setupPhoneMask);

    // =========================================================================
    // 8. FORM SUBMISSION (152-FZ COMPLIANCE & API SYNC)
    // =========================================================================
    async function submitLead(payload) {
        try {
            const resp = await fetch('/api/leads', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if (resp.ok) return await resp.json();
        } catch (e) {
            console.warn('API submission failed, saving locally:', e);
        }

        // Fallback: save to localStorage
        const stored = JSON.parse(localStorage.getItem('dd_leads') || '[]');
        const fallbackLead = {
            id: Date.now(),
            name: payload.name,
            phone: payload.phone,
            service: payload.service || 'Консультация',
            comment: payload.comment || '',
            date: new Date().toISOString(),
            status: 'new'
        };
        stored.unshift(fallbackLead);
        localStorage.setItem('dd_leads', JSON.stringify(stored));
        return { success: true, lead: fallbackLead };
    }

    // Lead Form (Section)
    const leadForm = document.getElementById('leadForm');
    leadForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('clientName')?.value.trim();
        const phone = document.getElementById('clientPhone')?.value.trim();
        const service = document.getElementById('clientService')?.value;
        const compliance = document.getElementById('complianceCheck')?.checked;

        const digits = (phone || '').replace(/\D/g, '');
        if (!name || digits.length < 10) {
            alert('Пожалуйста, укажите ваше имя и контактный номер телефона.');
            return;
        }

        if (!compliance) {
            alert('Необходимо согласие на обработку персональных данных.');
            return;
        }

        const btn = document.getElementById('leadSubmitBtn');
        if (btn) {
            btn.disabled = true;
            btn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> <span>Отправка...</span>';
        }

        try {
            await submitLead({ name, phone, service });
            leadForm.reset();
            showToast('Спасибо! Ваша заявка принята. Мы перезвоним в течение 15 минут.');
        } finally {
            if (btn) {
                btn.disabled = false;
                btn.innerHTML = '<i class="fas fa-paper-plane"></i> <span>Отправить заявку</span>';
            }
        }
    });

    // Modal Form
    const modalLeadForm = document.getElementById('modalLeadForm');
    const modalSuccessBox = document.getElementById('modalSuccessBox');

    modalLeadForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const name = document.getElementById('modalName')?.value.trim();
        const phone = document.getElementById('modalPhone')?.value.trim();
        const service = document.getElementById('modalService')?.value;

        const digits = (phone || '').replace(/\D/g, '');
        if (!name || digits.length < 10) {
            alert('Пожалуйста, укажите ваше имя и контактный номер телефона.');
            return;
        }

        const submitBtn = modalLeadForm.querySelector('button[type="submit"]');
        if (submitBtn) {
            submitBtn.disabled = true;
            submitBtn.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Отправка...';
        }

        try {
            await submitLead({ name, phone, service });
            modalLeadForm.style.display = 'none';
            if (modalSuccessBox) modalSuccessBox.style.display = 'block';
        } finally {
            if (submitBtn) {
                submitBtn.disabled = false;
                submitBtn.innerHTML = '<i class="fas fa-check"></i> Записаться';
            }
        }
    });

    // =========================================================================
    // 9. MODAL LOGIC
    // =========================================================================
    const appointmentModal = document.getElementById('appointmentModal');

    function openAppointmentModal(preselectedService = '') {
        if (!appointmentModal) return;
        appointmentModal.classList.add('active');
        document.body.style.overflow = 'hidden';

        if (modalLeadForm) {
            modalLeadForm.style.display = 'block';
            modalLeadForm.reset();
        }
        if (modalSuccessBox) modalSuccessBox.style.display = 'none';

        if (preselectedService && document.getElementById('modalService')) {
            const select = document.getElementById('modalService');
            let found = false;
            for (let option of select.options) {
                if (option.text.toLowerCase().includes(preselectedService.toLowerCase()) || 
                    option.value.toLowerCase().includes(preselectedService.toLowerCase())) {
                    option.selected = true;
                    found = true;
                    break;
                }
            }
            if (!found) {
                const opt = document.createElement('option');
                opt.value = preselectedService;
                opt.text = preselectedService;
                opt.selected = true;
                select.add(opt);
            }
        }
    }

    function closeAppointmentModal() {
        if (!appointmentModal) return;
        appointmentModal.classList.remove('active');
        document.body.style.overflow = '';
    }

    document.querySelectorAll('[data-modal-open="appointmentModal"]').forEach(btn => {
        btn.addEventListener('click', (e) => {
            e.preventDefault();
            openAppointmentModal();
        });
    });

    document.querySelectorAll('[data-modal-close]').forEach(btn => {
        btn.addEventListener('click', closeAppointmentModal);
    });

    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && appointmentModal?.classList.contains('active')) {
            closeAppointmentModal();
        }
    });

    // =========================================================================
    // 10. MOBILE BURGER & DRAWER NAVIGATION (НАДЕЖНОЕ ЗАКРЫТИЕ НА СМАРТФОНАХ)
    // =========================================================================
    const burger = document.getElementById('burger');
    const mobileDrawer = document.getElementById('mobileDrawer');
    const navOverlay = document.getElementById('navOverlay');
    const navCloseBtn = document.getElementById('navCloseBtn');

    function openMobileNav() {
        burger?.classList.add('active');
        mobileDrawer?.classList.add('active');
        navOverlay?.classList.add('active');
        document.body.classList.add('drawer-open');
    }

    function closeMobileNav() {
        burger?.classList.remove('active');
        mobileDrawer?.classList.remove('active');
        navOverlay?.classList.remove('active');
        document.body.classList.remove('drawer-open');
    }

    // Burger button click
    burger?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        if (mobileDrawer?.classList.contains('active')) {
            closeMobileNav();
        } else {
            openMobileNav();
        }
    });

    // Close button click [X]
    navCloseBtn?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeMobileNav();
    });

    // Tap on dark background overlay to close
    navOverlay?.addEventListener('click', (e) => {
        e.preventDefault();
        e.stopPropagation();
        closeMobileNav();
    });

    // Clicking any link or action button inside mobile drawer closes it
    mobileDrawer?.querySelectorAll('a, button:not(#navCloseBtn)').forEach(el => {
        el.addEventListener('click', () => {
            closeMobileNav();
        });
    });

    // Close on Escape key
    document.addEventListener('keydown', (e) => {
        if (e.key === 'Escape' && mobileDrawer?.classList.contains('active')) {
            closeMobileNav();
        }
    });

    // =========================================================================
    // 11. TOAST NOTIFICATION
    // =========================================================================
    function showToast(message) {
        const toast = document.getElementById('toast');
        const toastText = document.getElementById('toastMessage');
        if (toastText) toastText.textContent = message;
        if (toast) {
            toast.classList.add('active');
            setTimeout(() => toast.classList.remove('active'), 4500);
        }
    }

    // Helper HTML escape
    function escapeHtml(text) {
        if (!text) return '';
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(text).replace(/[&<>"']/g, m => map[m]);
    }

    // Initialize application
    loadSiteData();
});
