/**
 * =========================================================================
 *  Стоматология «Добрый Доктор» (г. Сургут) — Admin Panel JavaScript (CMS)
 *  Full CRUD System + Interactive Photo Cropper / Framing Area Selector
 * =========================================================================
 */

document.addEventListener('DOMContentLoaded', () => {

    // =========================================================================
    // 1. AUTHENTICATION GUARD
    // =========================================================================
    const isAuth = sessionStorage.getItem('dd_auth') === 'true' || localStorage.getItem('dd_auth') === 'true';
    if (!isAuth && !window.location.pathname.includes('login.html')) {
        window.location.href = 'login.html';
        return;
    }

    // Logout
    document.getElementById('logoutBtn')?.addEventListener('click', () => {
        if (confirm('Вы уверены, что хотите выйти из панели управления?')) {
            sessionStorage.removeItem('dd_auth');
            sessionStorage.removeItem('dd_user');
            localStorage.removeItem('dd_auth');
            window.location.href = 'login.html';
        }
    });

    // =========================================================================
    // 2. STATE & API HELPERS
    // =========================================================================
    let currentDB = {
        clinic: {},
        hero: {},
        services: [],
        doctors: [],
        gallery: [],
        leads: []
    };

    // Load full database
    async function fetchDB() {
        try {
            const resp = await fetch('/api/data', { cache: 'no-store' });
            if (resp.ok) {
                currentDB = await resp.json();
                currentDB.doctors = currentDB.doctors || [];
                localStorage.setItem('dd_cached_db', JSON.stringify(currentDB));
                renderAll();
                return;
            }
        } catch (e) {
            console.warn('Backend REST API unavailable, fallback to local cache / JSON file');
        }

        // Fallback
        const cached = localStorage.getItem('dd_cached_db');
        if (cached) {
            currentDB = JSON.parse(cached);
            currentDB.doctors = currentDB.doctors || [];
        } else {
            try {
                const staticResp = await fetch('../data/database.json');
                if (staticResp.ok) {
                    currentDB = await staticResp.json();
                    currentDB.doctors = currentDB.doctors || [];
                }
            } catch (err) {
                console.error(err);
            }
        }
        renderAll();
    }

    // =========================================================================
    // 3. TAB NAVIGATION & MOBILE SIDEBAR DRAWER
    // =========================================================================
    const sidebar = document.getElementById('sidebar');
    const sidebarOverlay = document.getElementById('sidebarOverlay');
    const sidebarToggle = document.getElementById('sidebarToggle');
    const sidebarCloseBtn = document.getElementById('sidebarCloseBtn');
    const sidebarItems = document.querySelectorAll('.sidebar__item[data-tab]');
    const tabPanels = document.querySelectorAll('.tab-panel');
    const titleHeader = document.getElementById('currentSectionTitle');

    const tabTitles = {
        leads: 'Заявки (Лиды)',
        settings: 'Тексты и Настройки клиники',
        services: 'Услуги и цены',
        doctors: 'Наши специалисты',
        media: 'Медиа / Фотогалерея'
    };

    sidebarItems.forEach(item => {
        item.addEventListener('click', (e) => {
            e.preventDefault();
            const tabId = item.dataset.tab;
            if (!tabId) return;

            sidebarItems.forEach(i => i.classList.remove('active'));
            tabPanels.forEach(p => p.classList.remove('active'));

            item.classList.add('active');
            document.getElementById(`tab-${tabId}`)?.classList.add('active');
            if (titleHeader) titleHeader.textContent = tabTitles[tabId] || 'Панель управления';

            // Close mobile sidebar
            closeSidebarDrawer();
        });
    });

    function openSidebarDrawer() {
        sidebar?.classList.add('active');
        sidebarOverlay?.classList.add('active');
    }

    function closeSidebarDrawer() {
        sidebar?.classList.remove('active');
        sidebarOverlay?.classList.remove('active');
    }

    sidebarToggle?.addEventListener('click', openSidebarDrawer);
    sidebarCloseBtn?.addEventListener('click', closeSidebarDrawer);
    sidebarOverlay?.addEventListener('click', closeSidebarDrawer);

    // =========================================================================
    // 4. TAB 1: LEADS MANAGEMENT (CRUD)
    // =========================================================================
    const leadsTableBody = document.getElementById('leadsTableBody');
    const leadsBadge = document.getElementById('leadsBadge');
    const leadsEmpty = document.getElementById('leadsEmptyState');
    const leadsSearch = document.getElementById('leadsSearch');
    const leadsFilterStatus = document.getElementById('leadsFilterStatus');

    const statusLabels = {
        new: 'Новая',
        processing: 'В обработке',
        done: 'Завершена'
    };

    const nextStatusMap = {
        new: 'processing',
        processing: 'done',
        done: 'new'
    };

    function renderLeads() {
        if (!leadsTableBody) return;
        const leads = currentDB.leads || [];

        // Count new leads
        const newCount = leads.filter(l => l.status === 'new').length;
        if (leadsBadge) leadsBadge.textContent = newCount;

        // Filtering & Search
        const filterVal = leadsFilterStatus?.value || 'all';
        const searchVal = leadsSearch?.value.toLowerCase().trim() || '';

        const filtered = leads.filter(lead => {
            const matchesStatus = filterVal === 'all' || lead.status === filterVal;
            const matchesSearch = !searchVal || 
                (lead.name && lead.name.toLowerCase().includes(searchVal)) ||
                (lead.phone && lead.phone.includes(searchVal)) ||
                (lead.service && lead.service.toLowerCase().includes(searchVal));
            return matchesStatus && matchesSearch;
        });

        if (filtered.length === 0) {
            leadsTableBody.innerHTML = '';
            if (leadsEmpty) leadsEmpty.style.display = 'block';
            return;
        }

        if (leadsEmpty) leadsEmpty.style.display = 'none';

        leadsTableBody.innerHTML = filtered.map((lead, idx) => `
            <tr>
                <td><strong>#${lead.id || (idx + 1)}</strong></td>
                <td>
                    <strong>${escapeHtml(lead.name)}</strong>
                </td>
                <td>
                    <a href="tel:${escapeHtml(lead.phone)}" style="font-weight: 600; white-space:nowrap;">
                        <i class="fas fa-phone-alt"></i> ${escapeHtml(lead.phone)}
                    </a>
                </td>
                <td>
                    <span>${escapeHtml(lead.service || 'Консультация')}</span>
                    ${lead.comment ? `<div style="font-size: 11px; color: var(--adm-text-muted);">${escapeHtml(lead.comment)}</div>` : ''}
                </td>
                <td style="white-space:nowrap;">${formatDateTime(lead.date)}</td>
                <td>
                    <select class="status-select status-select--${lead.status || 'new'}" data-lead-status-select="${lead.id}">
                        <option value="new" ${lead.status === 'new' ? 'selected' : ''}>🔵 Новая</option>
                        <option value="processing" ${lead.status === 'processing' ? 'selected' : ''}>🟠 В обработке</option>
                        <option value="done" ${lead.status === 'done' ? 'selected' : ''}>🟢 Завершена</option>
                    </select>
                </td>
                <td>
                    <div style="display: flex; gap: 6px;">
                        <button class="btn btn--danger btn--sm" title="Удалить заявку" data-lead-delete="${lead.id}">
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');

        // Attach status select change handler
        leadsTableBody.querySelectorAll('[data-lead-status-select]').forEach(select => {
            select.addEventListener('change', (e) => {
                const id = parseInt(select.getAttribute('data-lead-status-select'), 10);
                const newStatus = e.target.value;
                setLeadStatus(id, newStatus, select);
            });
        });

        // Attach delete handler
        leadsTableBody.querySelectorAll('[data-lead-delete]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-lead-delete'), 10);
                deleteLead(id);
            });
        });
    }

    async function setLeadStatus(id, newStatus, selectEl) {
        const lead = (currentDB.leads || []).find(l => l.id === id);
        if (!lead) return;
        lead.status = newStatus;

        // Update select class styling
        if (selectEl) {
            selectEl.className = `status-select status-select--${newStatus}`;
        }

        try {
            await fetch(`/api/leads/${id}`, {
                method: 'PUT',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ status: newStatus })
            });
        } catch (e) {
            console.warn(e);
        }

        saveToLocalStorage();
        
        // Update new leads badge in sidebar
        const newCount = (currentDB.leads || []).filter(l => l.status === 'new').length;
        if (leadsBadge) leadsBadge.textContent = newCount;

        showAdminToast(`Статус заявки #${id} изменен на: «${statusLabels[newStatus]}»`);
    }

    async function deleteLead(id) {
        if (!confirm('Вы точно хотите удалить данную заявку?')) return;
        currentDB.leads = (currentDB.leads || []).filter(l => l.id !== id);

        try {
            await fetch(`/api/leads/${id}`, { method: 'DELETE' });
        } catch (e) {
            console.warn(e);
        }

        saveToLocalStorage();
        renderLeads();
        showAdminToast('Заявка успешно удалена');
    }

    leadsSearch?.addEventListener('input', renderLeads);
    leadsFilterStatus?.addEventListener('change', renderLeads);
    document.getElementById('refreshLeadsBtn')?.addEventListener('click', () => {
        fetchDB();
        showAdminToast('Данные обновлены');
    });

    // =========================================================================
    // 5. TAB 2: TEXTS & SETTINGS FORM
    // =========================================================================
    const configForm = document.getElementById('configForm');

    function populateSettingsForm() {
        const c = currentDB.clinic || {};
        const h = currentDB.hero || {};
        const w = c.workingHours || {};

        setVal('cfgClinicName', c.name || 'Добрый Доктор');
        setVal('cfgCity', c.city || 'Сургут');
        setVal('cfgAddress', c.address || 'г. Сургут, ул. 30 лет Победы, 44/А');
        setVal('cfgAddressDetails', c.addressDetails || 'этаж 2, офис 208');
        setVal('cfgPhone', c.phone || '+7 (922) 447-98-88');
        setVal('cfgRating', c.rating || '4.4');
        setVal('cfgRatingPlatform', c.ratingPlatform || 'Яндекс Карты');

        setVal('cfgWhatsapp', c.whatsapp || 'https://wa.me/79224479888');
        setVal('cfgTelegram', c.telegram || 'https://t.me/dobrydoctor_surgut');
        setVal('cfgVk', c.vk || 'https://vk.com/dobrydoctor_surgut');

        setVal('cfgHeroTitle', h.title || 'Стоматология «Добрый Доктор» — бережное лечение зубов в Сургуте');
        setVal('cfgHeroSubtitle', h.subtitle || 'Рейтинг 4.4 ⭐. Профессиональная команда, современное оборудование и комфортная атмосфера.');

        setVal('cfgHoursWeekdays', w.weekdays || '09:00 — 20:00');
        setVal('cfgHoursSaturday', w.saturday || '10:00 — 18:00');
        setVal('cfgHoursSunday', w.sunday || 'Выходной');
    }

    configForm?.addEventListener('submit', async (e) => {
        e.preventDefault();

        const updatedClinic = {
            name: getVal('cfgClinicName'),
            city: getVal('cfgCity'),
            address: getVal('cfgAddress'),
            addressDetails: getVal('cfgAddressDetails'),
            phone: getVal('cfgPhone'),
            phoneRaw: getVal('cfgPhone').replace(/\D/g, '').replace(/^8/, '+7'),
            rating: getVal('cfgRating'),
            ratingPlatform: getVal('cfgRatingPlatform'),
            whatsapp: getVal('cfgWhatsapp'),
            telegram: getVal('cfgTelegram'),
            vk: getVal('cfgVk'),
            workingHours: {
                weekdays: getVal('cfgHoursWeekdays'),
                saturday: getVal('cfgHoursSaturday'),
                sunday: getVal('cfgHoursSunday')
            }
        };

        const updatedHero = {
            title: getVal('cfgHeroTitle'),
            subtitle: getVal('cfgHeroSubtitle')
        };

        currentDB.clinic = { ...currentDB.clinic, ...updatedClinic };
        currentDB.hero = { ...currentDB.hero, ...updatedHero };

        try {
            await fetch('/api/config', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ clinic: updatedClinic, hero: updatedHero })
            });
        } catch (err) {
            console.warn('API config update failed, cached locally:', err);
        }

        saveToLocalStorage();
        showAdminToast('Настройки и тексты успешно сохранены!');
    });

    // =========================================================================
    // 6. TAB 3: SERVICES MANAGEMENT (CRUD)
    // =========================================================================
    const servicesTableBody = document.getElementById('servicesTableBody');
    const serviceModal = document.getElementById('serviceModal');
    const serviceEditForm = document.getElementById('serviceEditForm');

    const catLabels = {
        therapy: 'Терапия',
        surgery: 'Хирургия',
        orthopedics: 'Ортопедия',
        hygiene: 'Профилактика',
        implant: 'Имплантация',
        kids: 'Детская'
    };

    function renderServicesTable() {
        if (!servicesTableBody) return;
        const services = currentDB.services || [];

        servicesTableBody.innerHTML = services.map(s => `
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 10px;">
                        <i class="fas ${s.icon || 'fa-tooth'}" style="color: var(--adm-primary); width: 20px;"></i>
                        <div>
                            <strong>${escapeHtml(s.title)}</strong>
                            <div style="font-size: 11px; color: var(--adm-text-muted); max-width: 320px;">
                                ${escapeHtml(s.description || '')}
                            </div>
                        </div>
                    </div>
                </td>
                <td>${catLabels[s.category] || s.category}</td>
                <td style="white-space:nowrap;"><strong>от ${Number(s.priceFrom || 0).toLocaleString('ru-RU')} ₽</strong></td>
                <td>${s.badge ? `<span class="status-pill status-pill--new">${escapeHtml(s.badge)}</span>` : '—'}</td>
                <td>
                    <span class="status-pill ${s.active !== false ? 'status-pill--active' : 'status-pill--inactive'}">
                        ${s.active !== false ? 'Активна' : 'Скрыта'}
                    </span>
                </td>
                <td>
                    <div style="display: flex; gap: 6px;">
                        <button class="btn btn--outline btn--sm" data-service-edit="${s.id}">
                            <i class="fas fa-pen"></i>
                        </button>
                        <button class="btn btn--danger btn--sm" data-service-delete="${s.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');

        servicesTableBody.querySelectorAll('[data-service-edit]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-service-edit'), 10);
                openServiceModal(id);
            });
        });

        servicesTableBody.querySelectorAll('[data-service-delete]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-service-delete'), 10);
                deleteService(id);
            });
        });
    }

    document.getElementById('openAddServiceModalBtn')?.addEventListener('click', () => {
        openServiceModal();
    });

    function openServiceModal(serviceId = null) {
        if (!serviceModal) return;
        serviceEditForm?.reset();

        const titleHeader = document.getElementById('serviceModalTitle');

        if (serviceId) {
            const s = (currentDB.services || []).find(item => item.id === serviceId);
            if (!s) return;
            if (titleHeader) titleHeader.textContent = 'Редактировать услугу';
            setVal('modalServiceId', s.id);
            setVal('modalServiceTitle', s.title);
            setVal('modalServiceCategory', s.category);
            setVal('modalServicePrice', s.priceFrom);
            setVal('modalServiceIcon', s.icon || 'fa-tooth');
            setVal('modalServiceBadge', s.badge || '');
            setVal('modalServiceDesc', s.description || '');
        } else {
            if (titleHeader) titleHeader.textContent = 'Добавить услугу';
            setVal('modalServiceId', '');
            setVal('modalServiceIcon', 'fa-tooth');
        }

        serviceModal.classList.add('active');
    }

    serviceEditForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const idVal = getVal('modalServiceId');
        const servicePayload = {
            id: idVal ? parseInt(idVal, 10) : undefined,
            title: getVal('modalServiceTitle'),
            category: getVal('modalServiceCategory'),
            priceFrom: parseInt(getVal('modalServicePrice'), 10) || 0,
            icon: getVal('modalServiceIcon') || 'fa-tooth',
            badge: getVal('modalServiceBadge'),
            description: getVal('modalServiceDesc'),
            active: true
        };

        try {
            const resp = await fetch('/api/services', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(servicePayload)
            });
            if (resp.ok) {
                const resData = await resp.json();
                currentDB.services = resData.services;
            }
        } catch (err) {
            currentDB.services = currentDB.services || [];
            if (servicePayload.id) {
                const idx = currentDB.services.findIndex(s => s.id === servicePayload.id);
                if (idx !== -1) currentDB.services[idx] = servicePayload;
            } else {
                servicePayload.id = Date.now();
                currentDB.services.push(servicePayload);
            }
        }

        saveToLocalStorage();
        renderServicesTable();
        serviceModal?.classList.remove('active');
        showAdminToast('Услуга успешно сохранена');
    });

    async function deleteService(id) {
        if (!confirm('Удалить эту услугу из прайс-листа?')) return;
        currentDB.services = (currentDB.services || []).filter(s => s.id !== id);

        try {
            await fetch(`/api/services/${id}`, { method: 'DELETE' });
        } catch (e) {
            console.warn(e);
        }

        saveToLocalStorage();
        renderServicesTable();
        showAdminToast('Услуга удалена');
    }

    // =========================================================================
    // 7. TAB 4: DOCTORS MANAGEMENT & INTERACTIVE PHOTO CROPPER
    // =========================================================================
    const doctorsTableBody = document.getElementById('doctorsTableBody');
    const doctorModal = document.getElementById('doctorModal');
    const doctorEditForm = document.getElementById('doctorEditForm');

    // Cropper State
    const cropperCanvas = document.getElementById('cropperCanvas');
    const cropperCtx = cropperCanvas?.getContext('2d');
    const cropZoomSlider = document.getElementById('cropZoomSlider');
    const doctorFileInput = document.getElementById('doctorFileInput');
    const photoDropzone = document.getElementById('photoDropzone');
    const loadUrlPhotoBtn = document.getElementById('loadUrlPhotoBtn');
    const modalDoctorPhotoUrl = document.getElementById('modalDoctorPhotoUrl');

    let cropperImage = new Image();
    let cropState = {
        loaded: false,
        zoom: 1.0,
        offsetX: 0,
        offsetY: 0,
        isDragging: false,
        startX: 0,
        startY: 0
    };

    function initCropper() {
        if (!cropperCanvas || !cropperCtx) return;

        // Draw routine
        function redrawCropper() {
            if (!cropperCtx) return;
            const w = cropperCanvas.width;
            const h = cropperCanvas.height;

            cropperCtx.fillStyle = '#0F172A';
            cropperCtx.fillRect(0, 0, w, h);

            if (!cropState.loaded || !cropperImage.width) {
                cropperCtx.fillStyle = '#64748B';
                cropperCtx.font = '13px Montserrat, sans-serif';
                cropperCtx.textAlign = 'center';
                cropperCtx.fillText('Загрузите фото врача', w / 2, h / 2);
                return;
            }

            // Calculate scaled dimensions to cover canvas
            const imgAspect = cropperImage.width / cropperImage.height;
            const canvasAspect = w / h;

            let drawW, drawH;
            if (imgAspect > canvasAspect) {
                drawH = h * cropState.zoom;
                drawW = drawH * imgAspect;
            } else {
                drawW = w * cropState.zoom;
                drawH = drawW / imgAspect;
            }

            const centerX = (w - drawW) / 2 + cropState.offsetX;
            const centerY = (h - drawH) / 2 + cropState.offsetY;

            cropperCtx.drawImage(cropperImage, centerX, centerY, drawW, drawH);
        }

        // Load image source into cropper
        function loadCropperSource(src) {
            cropperImage = new Image();
            cropperImage.crossOrigin = 'anonymous';
            cropperImage.onload = () => {
                cropState.loaded = true;
                cropState.zoom = 1.0;
                cropState.offsetX = 0;
                cropState.offsetY = 0;
                if (cropZoomSlider) cropZoomSlider.value = 1.0;
                redrawCropper();
            };
            cropperImage.src = src;
        }

        // File selection
        doctorFileInput?.addEventListener('change', (e) => {
            const file = e.target.files?.[0];
            if (file) {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    loadCropperSource(ev.target.result);
                };
                reader.readAsDataURL(file);
            }
        });

        // Dropzone drag-and-drop
        photoDropzone?.addEventListener('dragover', (e) => {
            e.preventDefault();
            photoDropzone.classList.add('dragover');
        });
        photoDropzone?.addEventListener('dragleave', () => {
            photoDropzone.classList.remove('dragover');
        });
        photoDropzone?.addEventListener('drop', (e) => {
            e.preventDefault();
            photoDropzone.classList.remove('dragover');
            const file = e.dataTransfer.files?.[0];
            if (file && file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (ev) => {
                    loadCropperSource(ev.target.result);
                };
                reader.readAsDataURL(file);
            }
        });

        // Load URL
        loadUrlPhotoBtn?.addEventListener('click', () => {
            const urlVal = modalDoctorPhotoUrl?.value.trim();
            if (urlVal) loadCropperSource(urlVal);
        });

        // Zoom Slider
        cropZoomSlider?.addEventListener('input', (e) => {
            cropState.zoom = parseFloat(e.target.value);
            redrawCropper();
        });

        // Preset alignments
        document.getElementById('cropAlignTopBtn')?.addEventListener('click', () => {
            cropState.offsetY = 35;
            redrawCropper();
        });
        document.getElementById('cropAlignCenterBtn')?.addEventListener('click', () => {
            cropState.offsetX = 0;
            cropState.offsetY = 0;
            redrawCropper();
        });
        document.getElementById('cropResetBtn')?.addEventListener('click', () => {
            cropState.zoom = 1.0;
            cropState.offsetX = 0;
            cropState.offsetY = 0;
            if (cropZoomSlider) cropZoomSlider.value = 1.0;
            redrawCropper();
        });

        // Interactive Dragging (Mouse & Touch)
        const viewport = document.getElementById('cropperViewport');

        function startDrag(clientX, clientY) {
            if (!cropState.loaded) return;
            cropState.isDragging = true;
            cropState.startX = clientX - cropState.offsetX;
            cropState.startY = clientY - cropState.offsetY;
        }

        function moveDrag(clientX, clientY) {
            if (!cropState.isDragging) return;
            cropState.offsetX = clientX - cropState.startX;
            cropState.offsetY = clientY - cropState.startY;
            redrawCropper();
        }

        function stopDrag() {
            cropState.isDragging = false;
        }

        viewport?.addEventListener('mousedown', (e) => startDrag(e.clientX, e.clientY));
        window.addEventListener('mousemove', (e) => moveDrag(e.clientX, e.clientY));
        window.addEventListener('mouseup', stopDrag);

        viewport?.addEventListener('touchstart', (e) => {
            if (e.touches.length === 1) startDrag(e.touches[0].clientX, e.touches[0].clientY);
        }, { passive: true });
        window.addEventListener('touchmove', (e) => {
            if (cropState.isDragging && e.touches.length === 1) moveDrag(e.touches[0].clientX, e.touches[0].clientY);
        }, { passive: true });
        window.addEventListener('touchend', stopDrag);

        // Expose load method
        window.loadDoctorCropper = loadCropperSource;
        redrawCropper();
    }

    initCropper();

    function renderDoctorsTable() {
        if (!doctorsTableBody) return;
        const doctors = currentDB.doctors || [];

        if (doctors.length === 0) {
            doctorsTableBody.innerHTML = `<tr><td colspan="6" style="text-align:center; padding:30px; color:var(--adm-text-muted);">Специалисты пока не добавлены. Нажмите «Добавить специалиста».</td></tr>`;
            return;
        }

        doctorsTableBody.innerHTML = doctors.map(doc => `
            <tr>
                <td>
                    <div style="display: flex; align-items: center; gap: 12px;">
                        <img src="${escapeHtml(doc.photo || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=150&q=80')}" alt="${escapeHtml(doc.name)}" style="width: 46px; height: 46px; border-radius: 50%; object-fit: cover; border: 2px solid var(--adm-border); flex-shrink:0;">
                        <div>
                            <strong>${escapeHtml(doc.name)}</strong>
                            <div style="font-size: 11px; color: var(--adm-text-muted); max-width: 300px;">${escapeHtml(doc.description || '')}</div>
                        </div>
                    </div>
                </td>
                <td style="white-space:nowrap;"><strong>${escapeHtml(doc.specialization)}</strong></td>
                <td style="white-space:nowrap;">${doc.experience || 10} лет</td>
                <td>${doc.badge ? `<span class="status-pill status-pill--new">${escapeHtml(doc.badge)}</span>` : '—'}</td>
                <td>
                    <span class="status-pill ${doc.active !== false ? 'status-pill--active' : 'status-pill--inactive'}">
                        ${doc.active !== false ? 'Активен' : 'Скрыт'}
                    </span>
                </td>
                <td>
                    <div style="display: flex; gap: 6px;">
                        <button class="btn btn--outline btn--sm" data-doctor-edit="${doc.id}">
                            <i class="fas fa-pen"></i>
                        </button>
                        <button class="btn btn--danger btn--sm" data-doctor-delete="${doc.id}">
                            <i class="fas fa-trash"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `).join('');

        doctorsTableBody.querySelectorAll('[data-doctor-edit]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-doctor-edit'), 10);
                openDoctorModal(id);
            });
        });

        doctorsTableBody.querySelectorAll('[data-doctor-delete]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-doctor-delete'), 10);
                deleteDoctor(id);
            });
        });
    }

    document.getElementById('openAddDoctorModalBtn')?.addEventListener('click', () => {
        openDoctorModal();
    });

    function openDoctorModal(docId = null) {
        if (!doctorModal) return;
        doctorEditForm?.reset();

        const titleHeader = document.getElementById('doctorModalTitle');

        if (docId) {
            const doc = (currentDB.doctors || []).find(d => d.id === docId);
            if (!doc) return;
            if (titleHeader) titleHeader.textContent = 'Редактировать специалиста';
            setVal('modalDoctorId', doc.id);
            setVal('modalDoctorName', doc.name);
            setVal('modalDoctorSpec', doc.specialization);
            setVal('modalDoctorExp', doc.experience || 10);
            setVal('modalDoctorPhotoUrl', doc.photo && doc.photo.startsWith('http') ? doc.photo : '');
            setVal('modalDoctorBadge', doc.badge || '');
            setVal('modalDoctorDesc', doc.description || '');

            if (doc.photo && window.loadDoctorCropper) {
                window.loadDoctorCropper(doc.photo);
            }
        } else {
            if (titleHeader) titleHeader.textContent = 'Добавить специалиста';
            setVal('modalDoctorId', '');
            setVal('modalDoctorExp', '10');
            const defaultPhoto = 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80';
            setVal('modalDoctorPhotoUrl', defaultPhoto);
            if (window.loadDoctorCropper) window.loadDoctorCropper(defaultPhoto);
        }

        doctorModal.classList.add('active');
    }

    doctorEditForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const idVal = getVal('modalDoctorId');

        // Export cropped photo from canvas
        let finalPhoto = getVal('modalDoctorPhotoUrl') || 'https://images.unsplash.com/photo-1622253692010-333f2da6031d?auto=format&fit=crop&w=600&q=80';
        if (cropperCanvas && cropState.loaded) {
            try {
                finalPhoto = cropperCanvas.toDataURL('image/jpeg', 0.88);
            } catch (err) {
                console.warn('Canvas export failed (CORS), using URL source:', err);
            }
        }

        const doctorPayload = {
            id: idVal ? parseInt(idVal, 10) : undefined,
            name: getVal('modalDoctorName'),
            specialization: getVal('modalDoctorSpec'),
            experience: parseInt(getVal('modalDoctorExp'), 10) || 5,
            photo: finalPhoto,
            badge: getVal('modalDoctorBadge'),
            description: getVal('modalDoctorDesc'),
            active: true
        };

        try {
            const resp = await fetch('/api/doctors', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(doctorPayload)
            });
            if (resp.ok) {
                const resData = await resp.json();
                currentDB.doctors = resData.doctors;
            }
        } catch (err) {
            currentDB.doctors = currentDB.doctors || [];
            if (doctorPayload.id) {
                const idx = currentDB.doctors.findIndex(d => d.id === doctorPayload.id);
                if (idx !== -1) currentDB.doctors[idx] = doctorPayload;
            } else {
                doctorPayload.id = Date.now();
                currentDB.doctors.push(doctorPayload);
            }
        }

        saveToLocalStorage();
        renderDoctorsTable();
        doctorModal?.classList.remove('active');
        showAdminToast('Данные специалиста и фото успешно сохранены!');
    });

    async function deleteDoctor(id) {
        if (!confirm('Удалить этого специалиста из списка?')) return;
        currentDB.doctors = (currentDB.doctors || []).filter(d => d.id !== id);

        try {
            await fetch(`/api/doctors/${id}`, { method: 'DELETE' });
        } catch (e) {
            console.warn(e);
        }

        saveToLocalStorage();
        renderDoctorsTable();
        showAdminToast('Специалист удален');
    }

    // =========================================================================
    // 8. TAB 5: MEDIA & GALLERY (CRUD)
    // =========================================================================
    const adminMediaGrid = document.getElementById('adminMediaGrid');
    const mediaModal = document.getElementById('mediaModal');
    const mediaAddForm = document.getElementById('mediaAddForm');

    function renderMediaGallery() {
        if (!adminMediaGrid) return;
        const gallery = currentDB.gallery || [];

        adminMediaGrid.innerHTML = gallery.map(item => `
            <div class="admin-media-card">
                <div class="admin-media-card__img">
                    <img src="${escapeHtml(item.url)}" alt="${escapeHtml(item.title)}">
                </div>
                <div class="admin-media-card__info">
                    <span class="admin-media-card__cat">${escapeHtml(item.category)}</span>
                    <h4 class="admin-media-card__title">${escapeHtml(item.title)}</h4>
                </div>
                <div class="admin-media-card__actions">
                    <button class="btn btn--danger btn--sm" data-media-delete="${item.id}">
                        <i class="fas fa-trash"></i> Удалить
                    </button>
                </div>
            </div>
        `).join('');

        adminMediaGrid.querySelectorAll('[data-media-delete]').forEach(btn => {
            btn.addEventListener('click', () => {
                const id = parseInt(btn.getAttribute('data-media-delete'), 10);
                deleteMedia(id);
            });
        });
    }

    document.getElementById('openAddMediaModalBtn')?.addEventListener('click', () => {
        mediaAddForm?.reset();
        mediaModal?.classList.add('active');
    });

    mediaAddForm?.addEventListener('submit', async (e) => {
        e.preventDefault();
        const payload = {
            title: getVal('mediaTitle'),
            category: getVal('mediaCategory'),
            url: getVal('mediaUrl')
        };

        try {
            const resp = await fetch('/api/gallery', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify(payload)
            });
            if (resp.ok) {
                const resData = await resp.json();
                currentDB.gallery = resData.gallery;
            }
        } catch (e) {
            payload.id = Date.now();
            currentDB.gallery = currentDB.gallery || [];
            currentDB.gallery.push(payload);
        }

        saveToLocalStorage();
        renderMediaGallery();
        mediaModal?.classList.remove('active');
        showAdminToast('Фотография добавлена в галерею');
    });

    async function deleteMedia(id) {
        if (!confirm('Удалить изображение?')) return;
        currentDB.gallery = (currentDB.gallery || []).filter(g => g.id !== id);

        try {
            await fetch(`/api/gallery/${id}`, { method: 'DELETE' });
        } catch (e) {
            console.warn(e);
        }

        saveToLocalStorage();
        renderMediaGallery();
        showAdminToast('Изображение удалено');
    }

    // Modal Close buttons
    document.querySelectorAll('[data-close-admin-modal]').forEach(btn => {
        btn.addEventListener('click', () => {
            document.querySelectorAll('.admin-modal').forEach(m => m.classList.remove('active'));
        });
    });

    // =========================================================================
    // 9. RENDER ALL & CACHING
    // =========================================================================
    function renderAll() {
        renderLeads();
        populateSettingsForm();
        renderServicesTable();
        renderDoctorsTable();
        renderMediaGallery();
    }

    function saveToLocalStorage() {
        localStorage.setItem('dd_cached_db', JSON.stringify(currentDB));
        localStorage.setItem('dd_leads', JSON.stringify(currentDB.leads || []));
    }

    // Helper functions
    function setVal(id, val) {
        const el = document.getElementById(id);
        if (el && val !== undefined) el.value = val;
    }

    function getVal(id) {
        return document.getElementById(id)?.value?.trim() || '';
    }

    function formatDateTime(iso) {
        if (!iso) return '—';
        const d = new Date(iso);
        const pad = n => String(n).padStart(2, '0');
        return `${pad(d.getDate())}.${pad(d.getMonth()+1)}.${d.getFullYear()} ${pad(d.getHours())}:${pad(d.getMinutes())}`;
    }

    function escapeHtml(str) {
        if (!str) return '';
        const map = { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' };
        return String(str).replace(/[&<>"']/g, m => map[m]);
    }

    function showAdminToast(msg) {
        const toast = document.getElementById('adminToast');
        const text = document.getElementById('adminToastMsg');
        if (text) text.textContent = msg;
        if (toast) {
            toast.classList.add('active');
            setTimeout(() => toast.classList.remove('active'), 3500);
        }
    }

    // Initial load & Polling for new leads
    fetchDB();
    setInterval(fetchDB, 8000);
});
